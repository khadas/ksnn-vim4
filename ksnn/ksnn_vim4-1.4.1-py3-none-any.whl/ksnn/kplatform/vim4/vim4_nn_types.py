import os,sys
from ctypes import *
from enum import Enum, unique

NPU_SUCCESS = 0
NPU_FAILE = 1
NPU_MAX_DIM_NUM = 8

NPU_BOOL8_SUPPORT = 0
NPU_BFLOAT16_SUPPORT = 0

if NPU_BOOL8_SUPPORT :
    NPU_NN_TYPE_BOOL8_VAL = 0 #Unknown
else :
    NPU_NN_TYPE_BOOL8_VAL = 0x11

if NPU_BFLOAT16_SUPPORT :
    NPU_NN_TYPE_BFLOAT16_VAL = 0 #UnKnown
else :
    NPU_NN_TYPE_BFLOAT16_VAL = 0x81A

class npu_dim_fmt_e(Enum):
    NPU_NN_DIM_FMT_NCHW = 0x00
    NPU_NN_DIM_FMT_NHWC = 0x01
    NPU_NN_DIM_FMT_NA   = 0xFF
    NPU_NN_DIM_FMT_AUTO = 0xFE  #NPU_NN_DIM_FMT_NA - 1

class npu_data_type_e(Enum):
    NPU_NN_TYPE_NONE = 0x000
    NPU_NN_TYPE_INT8 = 0x002
    NPU_NN_TYPE_INT16 = 0x004
    NPU_NN_TYPE_INT32 = 0x006
    NPU_NN_TYPE_INT64 = 0x008
    NPU_NN_TYPE_UINT8 = 0x003
    NPU_NN_TYPE_UINT16 = 0x005
    NPU_NN_TYPE_UINT32 = 0x007
    NPU_NN_TYPE_UINT64 = 0x009
    NPU_NN_TYPE_FLOAT16 = 0x00F
    NPU_NN_TYPE_FLOAT32 = 0x00A
    NPU_NN_TYPE_FLOAT64 = 0x00B
    NPU_NN_TYPE_BOOL8 = NPU_NN_TYPE_BOOL8_VAL
    NPU_NN_TYPE_BFLOAT16 = NPU_NN_TYPE_BFLOAT16_VAL
    NPU_NN_TYPE_VDATA = 0x101

class npu_qnt_type_e(Enum):
    NPU_NN_QNT_TYPE_NONE = 0
    NPU_NN_QNT_TYPE_DFP = 0x1
    NPU_NN_QNT_TYPE_AFFINE_ASYMMETRIC = 0x2
    NPU_NN_QNT_TYPE_affine_perchannel_symmetric = 0x3
    NPU_NN_QNT_TYPE_AFFINE_SYMMETRIC = 0x2
    NPU_NN_QNT_TYPE_NA = 0xff

class npu_dynamic_fixed_point(Structure):
    _fields_ = [
        ('fl', c_byte)
    ]

class npu_affine_asymmetric(Structure):
    _fields_ = [
        ('zero_point', c_int),
        ('scale', c_float)
    ]

class npu_affine_perchannel_symmetric(Structure):
    _fields_ = [
        ('scales', POINTER(c_float)),
        ('scale_dim', c_int),
        ('channel_dim', c_int),
        ('zero_points', POINTER(c_int)),
        ('zero_points_dim', c_int)
    ]

class npu_meanful(Union):
    _fields_ = [
        ('dynamic_fixed_point', npu_dynamic_fixed_point),
        ('affine_asymmetric', npu_affine_asymmetric),
        ('affine_perchannel_symmetric', npu_affine_perchannel_symmetric)
    ]

class npu_qdata(Structure):
    _fields_ = [
        ('qnt_type', c_char),
        ('meanful', npu_meanful)
    ]

class npu_dtype(Structure):
    _fields_ = [
        ('fmt', c_char),
        ('nn_type', c_int),
        ('qdata', npu_qdata)
    ]

class npu_memory_type_e(Enum):
    NPU_MEMORY_TYPE_NONE = 0x0,
    NPU_MEMORY_TYPE_HOST = 0x1,
    NPU_MEMORY_TYPE_DMABUF = 0x7,
    NPU_MEMORY_TYPE_INTERNAL = 0x8,
    NPU_MEMORY_TYPE_HOST_UNCACHED = 0x9,
    VSI_MEMORY_TYPE_PHYSICAL = 0xa

class npu_tensor(Structure):
    _fields_ = [
        ('size', c_uint*NPU_MAX_DIM_NUM),
        ('dim_num', c_uint),
        ('vtl', c_int),
        ('is_const', c_int),
        ('dtype', npu_dtype),
        ('is_created_from_handle', c_int),
        ('is_handle_malloc_by_ovxlib', c_int),
        ('npu_memory_type', c_char)
    ]

class npu_output_data(Structure):
    _fields_ = [
        ('type', c_uint),
        ('data', c_char_p),
        ('tensor', npu_tensor)
    ]


