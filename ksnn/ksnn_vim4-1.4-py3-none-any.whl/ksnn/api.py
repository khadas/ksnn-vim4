import os,sys
import ctypes
from ksnn.kplatform.vim4.vim4_nn_api import vim4_nn
from numpy import *
from ksnn.types import *
import cv2 as cv
import numpy as np
import time
import gc

VERSION = 'v1.4'
GC_NUM = 1000

def file_exist_judgment (file_path):
    '''Verify that the file exists
    '''
    if os.path.exists(file_path) == False:
        sys.exit(file_path + ' not exist')

class KSNN:
    '''Neural Network control interfance

    Class KSNN is the control interface for Neural Network, 
    
    all NPU-related functions and operations are included in this class.

    Attributes: 
        board: Board model. Board model list: VIM4
    '''

    def __init__ (self, board=None):

        if board == None:
            print('default board is VIM4')
            self.board = ksnn_board.BOARD_VIM4
        elif board == 'VIM4':
            self.board = ksnn_board.BOARD_VIM4
        elif board != 'VIM4':
            sys.exit('Unsupported board !!!')

    def get_nn_version (self):
        '''Print Neural Network Api version

        Args:
            None

        Returns:
            string: version
        '''

        return VERSION


    def nn_init (self, library=None, model=None, level=0):
        '''Create Neural Network

        Args:
            library: (Only valid for VIM4) The path for your C static librarys
            model:  The path for your model file.

        Returns:
            class: ksnn_stat

        '''

        if self.board == ksnn_board.BOARD_VIM4:
            if library :
                if os.path.exists(library) == False:
                    sys.exit('so lib \'' + library + '\' not exist')
                library = bytes(library,encoding='utf-8')
            else :
                sys.exit('Board VIM4 requires parameter \'library\'')
            if model :
                if os.path.exists(model) == False:
                    sys.exit('nb file \'' + model + '\' not exist')
                model = bytes(model,encoding='utf-8')
            else :
                sys.exit('Board VIM4 requires parameter \'model\'')
            if level > 1:
                os.environ['VIV_VX_DEBUG_LEVEL']='1'
                os.environ['VIV_VX_PROFILE']='1'
            else:
                os.environ['VIV_VX_DEBUG_LEVEL']='0'
                os.environ['VIV_VX_PROFILE']='0'
            self.ksnn_api = vim4_nn()
            val = self.ksnn_api.neural_network_init(library, model)
            if val == 0 :
                return ksnn_stat.STAT_SUCCESS
            else :
                return ksnn_stat.STAT_FAIL
        sys.exit('Unsupported board !!!')

    def nn_set_inputs (self, input_tensor, input_shape, input_type):
        '''Convert the data and set it into neural network

        Args: 
            input_tensor: Numpy array format data
            input_shape: The input shape of model
            input_type: Choose rgb input or raw input "RGB" or "RAW"

        Returns:
            class: ksnn_stat
        '''

        if self.board == ksnn_board.BOARD_VIM4:
            if input_type != "RGB" and input_type != "RAW":
                sys.exit('Unknown input type, available formats: RGB, RAW')
            
            if input_tensor.shape != input_shape:
                sys.exit('Input shape error, input shape does not equal ' + input_shape)

            input_size = 1
            for i in input_shape:
                input_size *= i
            
            if input_type == "RGB":
                val = self.ksnn_api.neural_network_set_input_rgb(input_tensor, input_size)
            
            if input_type == "RAW":
                val = self.ksnn_api.neural_network_set_input_raw(input_tensor, input_size)

            if val != 0 :
                return ksnn_stat.STAT_FAIL
            return ksnn_stat.STAT_SUCCESS
        sys.exit('Unsupported board !!!')

    def nn_run (self, output_type):

        '''Run neural network

        Args:
            output_type: Choose output type, "FLOAT" or "RAW"

        Return:
            class: ksnn_stat

        '''

        if self.board == ksnn_board.BOARD_VIM4:
            if output_type == "FLOAT":
                val = self.ksnn_api.neural_network_inference_float_output()
            if output_type == "RAW":
                val = self.ksnn_api.neural_network_inference_raw_output()
            if val == 0 :
                return ksnn_stat.STAT_SUCCESS
            else :
                return ksnn_stat.STAT_FAIL
        sys.exit('Unsupported board !!!')

    def nn_get_outputs (self, output_shape):

        '''Get outputs data after run Neural Network

        Args:
            None

        Returns:
            list(): List of numpy arrays

        '''

        out_data = list()
        if self.board == ksnn_board.BOARD_VIM4:
            self.ksnn_api.neural_network_get_output(out_data, output_shape)
            return out_data
        sys.exit('Unsupported board !!!')
    
    def nn_destory_network(self):
    	'''Get outputs data after run Neural Network

        Args:
            output_shape: All output shape

        Returns:
            class: ksnn_stat

        '''
        
    	val = self.ksnn_api.neural_network_destroy()
    	return val

    def nn_inference (self, input_array, input_shape, input_type, output_shape, output_type):

        '''nn_inference implements a unified interface from input to output

        Args:
            input_array: Numpy array format data
            input_shape: The input shape of model
            input_type: Choose rgb input or raw input "RGB" or "RAW"
            output_shape: All output shape
            output_type: Choose output type, "FLOAT" or "RAW"

        Returns:
            list(): List of numpy arrays
        '''
        global GC_NUM
        if self.board == ksnn_board.BOARD_VIM4:
            res = self.nn_set_inputs(input_tensor=input_array, input_shape=input_shape, input_type=input_type)
            if res == ksnn_stat.STAT_FAIL :
                sys.exit('Set nn inputs error !!!')

            res = self.nn_run(output_type)
            if res != ksnn_stat.STAT_SUCCESS :
                sys.exit('run neural network  error !!!')

            out_data = self.nn_get_outputs(output_shape)
            GC_NUM -= 1
            if GC_NUM == 0 :
                gc.collect()
                GC_NUM = 1000
            res = self.nn_destory_network()
            return out_data
        else :
            res = self.nn_destory_network()
            sys.exit('Unsupported board !!!')

