import os,sys
from ctypes import *
from ksnn.kplatform.vim4 import vim4_nn_types
import numpy as np

class vim4_nn:

    def npu_tool_version(self):
        version = self.detect_so.NPU_version
        version.argtypes = []
        version.restype = c_char_p
        ver =  version()
        return ver
    
    def neural_network_init(self, library, model_path):
        self.detect_so = CDLL(library)
        init_network_file = self.detect_so.init_network_file
        init_network_file.argtypes = [c_char_p]
        init_network_file.restype = c_int
        val = init_network_file(model_path)
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE
    
    def neural_network_set_input_rgb(self, rawdata, input_size):
        set_rgb_input = self.detect_so.set_rgb_input
        set_rgb_input.argtypes = [POINTER(c_ubyte), c_int]
        set_rgb_input.restype = c_int
        rawdata = rawdata.ctypes.data_as(POINTER(c_ubyte))
        val = set_rgb_input(rawdata, input_size)
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE
    
    def neural_network_set_input_raw(self, rawdata, input_size):
        set_raw_input = self.detect_so.set_raw_input
        set_raw_input.argtypes = [POINTER(c_ubyte), c_int]
        set_raw_input.restype = c_int
        rawdata = rawdata.ctypes.data_as(POINTER(c_ubyte))
        val = set_raw_input(rawdata, input_size)
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE

    def neural_network_inference_float_output(self):
        inference_float_output = self.detect_so.inference_float_output
        inference_float_output.argtypes = []
        inference_float_output.restype = c_int
        val = inference_float_output()
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE
    
    def neural_network_inference_raw_output(self):
        inference_raw_output = self.detect_so.inference_raw_output
        inference_raw_output.argtypes = []
        inference_raw_output.restype = c_int
        val = inference_raw_output()
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE
    
    def neural_network_get_output(self, output, output_shape):
        get_output = self.detect_so.get_output
        get_output.argtypes = [POINTER(c_float), c_int, c_int]
        get_output.restype = c_int
        output_len = len(output_shape)
        for i in range(output_len):
            tensor_size = 1
            for j in range(len(output_shape[i])):
                tensor_size *= output_shape[i][j]
            output_tensor = np.zeros(tensor_size, dtype=np.float32)
            output_tensor = output_tensor.ctypes.data_as(POINTER(c_float))
            val = get_output(output_tensor, i, tensor_size)
            output_tensor = np.ctypeslib.as_array(output_tensor, shape=(tensor_size,))
            output_tensor = output_tensor.reshape(output_shape[i])
            output.append(output_tensor)

        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE

    def neural_network_destroy(self):
        destroy_network = self.detect_so.destroy_network
        destroy_network.argtypes = []
        destroy_network.restype = c_int
        val = destroy_network()
        if vim4_nn_types.NPU_SUCCESS == val :
            return vim4_nn_types.NPU_SUCCESS
        else :
            return vim4_nn_types.NPU_FAILE

# ---------+ END OF Class neural_network +--------- 
